Version: 19.9.2017:  Bugfix Clearscreen, 	Malacarne, 	Version Version_1738-H01D02-R
Version: 14.11.2014: Neue Lib ver�ffentlicht,	Malacarne, 	Version Version_1450-H01D02-R