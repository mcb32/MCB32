// Rma 3.12.2023
// Cube und TouchP0P1 Lib integration
// Das File TouchP0P1.h heisst hier neu TouchP0P1_Cube.h  weil dort einigen Anpassungen f�r Cube vorgenommen worden sind.
//
// Cube ist ohne getrennte *.c und *.h Files aufgesetzt. Damit sind alle wichtigen Funktionen bei diesem Beispiel ( Template) 
// im Mainfile untergebracht und k�nnen dort  studiert werden. 
// Umstellen auf *.c und *.h sollte kein Problem sein. 
// *********************************************************************************

Schritt 1. 
Lade die beiden Libfiles   TouchP0P1_Cube.h und TouchP0P1.lib in den Pfad: ......\Core\Src
// *********************************************************************************
Schritt 2.
Includiere die Lib  TouchP0P1_Cube.h  wie folgt:

	/* Private includes ----------------------------------------------------------*/
		/* USER CODE BEGIN Includes */
		#include <stdio.h> // lib f�r sprintf()
		#include "TouchP0P1_Cube.h"
		/* USER CODE END Includes */
// *********************************************************************************
Schritt 3 f�r Beispiel Systick:
Passe  den User Code in main.c  wie folgt an:

		/* USER CODE BEGIN PV */
		uint64_t  privateHalTimer=0;    // unsigned long long  0 .. 18446744073709551615  (8Bytes)   
		 //  char wertausgabe[32];        // Array, Buffer f�r sprintf(wertausgabe,� �)
		 //  uint64_t  countSecNew=0;     // Count seconds
		 //  uint64_t countSecOld=0;      // Count seconds
		/* USER CODE END PV */
		
und .....

		/* USER CODE BEGIN 4 */
		/* ToDo:     Enable HAL_SYSTICK_IRQHandler();  in the SysTick_Handler(void) in File stm32f1xx_it.c 
		* Function:  void HAL_SYSTICK_Callback(void)     // was "__weak void HAL_SYSTICK_Callback(void)" in stm32f1xx_hal_cortex.c
		*            the Function is called from HAL_SYSTICK_IRQHandler(void) every ms
		*/
		void HAL_SYSTICK_Callback(void)
		{
			privateHalTimer++;                // Count ++ after 1ms via 
		}
		/* USER CODE END 4 */
// *********************************************************************************
Schritt 4: Passe den Code in stm32f1xx_it.c wie folgt an:
Damit wird z.Bsp alle 1ms ein Counter via HAL_SYSTICK_IRQHandler(); um 1 erh�ht. 
/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */
	 // HAL_IncTick();
     HAL_SYSTICK_IRQHandler();     // rma_2349 Set the IRQHandler for this APP
  /* USER CODE END SysTick_IRQn 0 */
     HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

// *********************************************************************************
Schritt 5: Pr�fe  File  stm32f1xx_hal_cortex.c  auf folgenden Inhalt: 
.......
.......
		/**
		  * @brief  This function handles SYSTICK interrupt request.
		  * @retval None
		  */
		void HAL_SYSTICK_IRQHandler(void)
		{
		   HAL_SYSTICK_Callback();     // RMA  Diese Funktion ist im Main neu programmiert (siehe unten) 
		}

		/**
		  * @brief  SYSTICK callback.
		  * @retval None
		  */
		__weak void HAL_SYSTICK_Callback(void)
		{
		  /* NOTE : This function Should not be modified, when the callback is needed,
					the HAL_SYSTICK_Callback could be implemented in the user file
		   */
		}
.......
.......

// *********************************************************************************
Schritt 6:  Initialisiere in Main den Touch  wie folgt

int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */
  /* MCU Configuration--------------------------------------------------------*/
  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();
  /* USER CODE BEGIN Init */
  /* USER CODE END Init */
  /* Configure the system clock */
	SystemClock_Config();
  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */
  /* Initialize all configured peripherals */
	  MX_GPIO_Init();
	  MX_ADC2_Init();
	  MX_DAC_Init();
	  MX_SPI2_Init();
	  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */
  InitTouchScreen();       // RMA:  nach allen anderen Inits hier den Touch initialsieren 
	 textxy(" MCB32 CUBE Demonstration:", 0, 92, BLACK, YELLOW);
	 printAt ( 8, "Show Seconds via Hal_Systick" );
  /* USER CODE END 2 */
  
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  
 // *********************************************************************************
 Schritt 7:  In Keil im Flash Configurator muss unter c/C++
             und Preprocessor Symbols das Feld Define: mit  folgendem Eintrag gef�llt sein:
 
   USE_HAL_DRIVER,STM32F107xC
 
 
// *********************************************************************************  Fertig 

